<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Ciclo Lectivo</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">

</head>

<body>

    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <div class="form-container">

            <div class="perfil-header">
                <h1>Agregar Ciclo Lectivo</h1>
            </div>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div id="alert-ajax" class="alert" style="display:none;"></div>

                <form id="form-ciclo"
                      method="POST"
                      action="<?php echo e(route('cicloLectivo.store')); ?>">

                    <?php echo csrf_field(); ?>

                    <div class="form-grid">

                        <label>Año *</label>
                            <div class="input-group">
                                <div class="input-with-help">
                                    <input
                                        type="number"
                                        id="anio"
                                        name="anio"
                                        min="2000"
                                        max="2100"
                                        placeholder="Ej: 2027"
                                        required>
                                     <div class="help-placeholder"></div>
                                </div>
                                <small id="error-anio" class="error-message"></small>
                            </div>

                        <label>Fecha de inicio *</label>
                            <div class="input-group">
                                <div class="input-with-help">
                                    <input
                                        type="date"
                                        id="fecha_inicio"
                                        name="fecha_inicio"
                                        required>
                                    <div class="help-icon">
                                        <i class="ri-question-line"></i>
                                        <div class="help-tooltip">Inicio del ciclo lectivo.</div>
                                    </div>
                                </div>
                                <small id="error-fecha_inicio" class="error-message"></small>
                            </div>

                        <label>Fecha de fin *</label>
                            <div class="input-group">
                                <div class="input-with-help">
                                    <input
                                        type="date"
                                        id="fecha_fin"
                                        name="fecha_fin"
                                        required>
                                    <div class="help-icon">
                                        <i class="ri-question-line"></i>
                                        <div class="help-tooltip">Debe ser posterior a la fecha de inicio.</div>
                                    </div>
                                </div>
                                <small id="error-fecha_fin" class="error-message"></small>
                            </div>

                        <label>Inicio matriculación *</label>
                            <div class="input-group">
                                <div class="input-with-help">
                                    <input
                                        type="date"
                                        id="inicio_matriculacion"
                                        name="inicio_matriculacion"
                                        required>
                                    <div class="help-icon">
                                        <i class="ri-question-line"></i>
                                        <div class="help-tooltip">Desde esta fecha los alumnos podrán inscribirse.</div>
                                    </div>
                                </div>
                                <small id="error-inicio_matriculacion" class="error-message"></small>
                            </div>



                        <label>Fin matriculación *</label>
                            <div class="input-group">
                                <div class="input-with-help">
                                    <input
                                        type="date"
                                        id="fin_matriculacion"
                                        name="fin_matriculacion"
                                        required>
                                    <div class="help-icon">
                                        <i class="ri-question-line"></i>
                                        <div class="help-tooltip">Hasta esta fecha podrán inscribirse.</div>
                                    </div>
                                </div>
                                <small id="error-fin_matriculacion" class="error-message"></small>
                            </div>
                    </div>

                    <div class="form-actions">

                        <button type="button" class="btn-secondary" onclick="window.location.href='<?php echo e(route('cicloLectivoSec')); ?>'">Volver</button>

                        <button type="submit" id="btn-guardar" class="btn-primary">
                        <i class="ri-save-line"></i>Guardar</button>

                    </div>
                </form>
        </div>
    </div>

<?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- <script>

(function(){

    const form=document.getElementById("form-ciclo");
    const btn=document.getElementById("btn-guardar");

    btn.addEventListener("click",function(){

        document.querySelectorAll(".error-message").forEach(e=>e.textContent="");

        document.querySelectorAll(".input-error").forEach(e=>e.classList.remove("input-error"));

            if(!form.checkValidity()){

            form.querySelectorAll(":invalid").forEach(function(campo){

                campo.classList.add("input-error");

                const error=document.getElementById("error-"+campo.id);

                    if(error){
                        error.textContent=campo.validationMessage;
                    }
            });

            form.reportValidity();
            return;}

        btn.disabled=true;

        btn.innerHTML='<i class="ri-loader-4-line ri-spin"></i> Guardando...';

        /*
        fetch()
        */

        setTimeout(()=>{

        btn.disabled=false;

        btn.innerHTML='<i class="ri-save-line"></i> Guardar';

        },1000);

    });

})();
</script> -->

</body>
</html>
<?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/cicloLectivoAgregar.blade.php ENDPATH**/ ?>