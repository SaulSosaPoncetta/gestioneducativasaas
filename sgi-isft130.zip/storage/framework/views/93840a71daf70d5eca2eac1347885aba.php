<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Finales</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/alumnosSec.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/Filtro.js']); ?>
</head>

<body>
    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">
        <!-- HEADER -->
        <div class="top-bar">
            <h1>Fechas de finales</h1>
            <div>
                <button class="btn-primary" onclick="window.location.href='<?php echo e(route('finalesAgregarFecha')); ?>'">Agregar fecha</button>
                <button class="btn-primary" onclick="window.location.href='<?php echo e(route('finalesHistorial')); ?>'">Informes</button>
            </div>
        </div>

        <!-- FILTROS — recargan la página con querystring; el backend
             (MesaExamenService::getAll) ya soporta id_carrera y anio -->
        <form method="GET" action="<?php echo e(route('finalesSec')); ?>">
            <div class="card-container">
                <div class="form-grid">
                    <label>Carrera</label>
                    <select name="id_carrera" onchange="this.form.submit()">
                        <option value="" <?php echo e(empty($filters['id_carrera']) ? 'selected' : ''); ?>>Todas</option>
                        <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($carrera->id_carrera); ?>"
                                <?php echo e((string) ($filters['id_carrera'] ?? '') === (string) $carrera->id_carrera ? 'selected' : ''); ?>

                            >
                                <?php echo e($carrera->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <label>Año</label>
                    <select name="anio" onchange="this.form.submit()">
                        <option value="" <?php echo e(empty($filters['anio']) ? 'selected' : ''); ?>>Todos</option>
                        <?php $__currentLoopData = $anios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($anio); ?>"
                                <?php echo e((string) ($filters['anio'] ?? '') === (string) $anio ? 'selected' : ''); ?>

                            >
                                <?php echo e($anio); ?>°
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </form>

        <div class="table-container">

            <table class="cursada-table">
                <thead>
                    <tr>
                        <th>Fecha y hora</th>
                        <th>Espacio</th>
                        <th>Carrera</th>
                        <th>Año</th>
                        <th>Profesores</th>
                        <th>Perfil</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $mesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($mesa->fecha_hora); ?></td>
                            <td><?php echo e($mesa->espacio); ?></td>
                            <td><?php echo e($mesa->carrera); ?></td>
                            <td><?php echo e($mesa->anio); ?></td>
                            <td><?php echo e($mesa->profesores); ?></td>
                            <td>
                                <button
                                    class="btn-primary"
                                    onclick="window.location.href='<?php echo e(route('finalPerfil', $mesa->id_mesa)); ?>'">
                                    Ver
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">No hay mesas de final cargadas.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/finales.blade.php ENDPATH**/ ?>