<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Perfil Profesor</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/Filtro.js']); ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/profesoresAgregar.css')); ?>">
</head>

<body>
    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <!-- href no anda para el button, hay que acordarse de que se usa onclick para button y href para a -->
        <button class="btn-modificar" type="button" onclick="window.location='<?php echo e(route('profesoresSec')); ?>'">
            <i class="ri-arrow-left-line"></i>Volver
        </button>

        <div class="form-container">

            <!-- HEADER -->
            <div class="perfil-header">
                <h1>Perfil Profesor</h1>
                <button class="btn-modificar" id="btn-modificar" type="button">
                    <i class="ri-edit-line"></i> Modificar
                </button>
            </div>

            
            <?php if(session('success')): ?>
                <div class="alert alert-success" id="alert-success">
                    <i class="ri-checkbox-circle-line"></i> <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div id="alert-ajax" class="alert" style="display:none;"></div>

            <?php
                $dni = $docente->usuario->dnis->first();
                $telefono = $docente->usuario->telefonos->first();
            ?>

            <!-- FORM -->
            <form id="form-profesor"
            data-perfil-editable
            data-update-url="<?php echo e(route('profesores.update', $docente->usuario->id_usuario)); ?>">
            
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-grid">

                    <label for="apellido">Apellido</label>
                    <div class="input-group">
                        <input type="text" name="apellido" id="apellido" value="<?php echo e($docente->usuario->apellido); ?>" disabled>
                        <small class="error-message" id="error-apellido"></small>
                    </div>

                    <label for="nombre">Nombre</label>
                    <div class="input-group">
                        <input type="text" name="nombre" id="nombre" value="<?php echo e($docente->usuario->nombre); ?>" disabled>
                        <small class="error-message" id="error-nombre"></small>
                    </div>

                    <label for="id_tipo_dni">Tipo de documento</label>
                    <div class="input-group">
                        <select name="id_tipo_dni" id="id_tipo_dni" disabled>
                            <option value="">Seleccionar</option>
                            <?php $__currentLoopData = $tiposDni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($tipo->id_tipo_dni); ?>"
                                    <?php echo e(($dni?->id_tipo_dni == $tipo->id_tipo_dni) ? 'selected' : ''); ?>>
                                    <?php echo e($tipo->descripcion); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="error-message" id="error-id_tipo_dni"></small>
                    </div>

                    <label for="dni">Documento</label>
                    <div class="input-group">
                        <input type="text" name="dni" id="dni" value="<?php echo e($dni?->dni ?? ''); ?>" disabled>
                        <small class="error-message" id="error-dni"></small>
                    </div>

                    <label for="genero">Género</label>
                    <div class="input-group">
                        <select name="genero" id="genero" disabled>
                            <option value="">Seleccionar</option>
                            <option value="Masculino" <?php echo e($docente->usuario->genero == 'Masculino' ? 'selected' : ''); ?>>Masculino</option>
                            <option value="Femenino"  <?php echo e($docente->usuario->genero == 'Femenino'  ? 'selected' : ''); ?>>Femenino</option>
                            <option value="Otro"      <?php echo e($docente->usuario->genero == 'Otro'      ? 'selected' : ''); ?>>Otro</option>
                        </select>
                        <small class="error-message" id="error-genero"></small>
                    </div>

                    <label for="cuil">CUIL/CUIT</label>
                    <div class="input-group">
                        <input type="text" name="cuil" id="cuil" value="<?php echo e($dni?->cuil ?? ''); ?>" disabled>
                        <small class="error-message" id="error-cuil"></small>
                    </div>

                    <label for="fecha_nacimiento">Fecha de nacimiento</label>
                    <div class="input-group">
                        <input
                            type="date"
                            name="fecha_nacimiento"
                            id="fecha_nacimiento"
                            value="<?php echo e($docente->usuario->fecha_nacimiento ? \Carbon\Carbon::parse($docente->usuario->fecha_nacimiento)->format('Y-m-d') : ''); ?>"
                            disabled
                        >
                        <small class="error-message" id="error-fecha_nacimiento"></small>
                    </div>

                    <label for="id_pais">Nacionalidad</label>
                    <div class="input-group">
                        <select name="id_pais" id="id_pais" disabled>
                            <option value="">Seleccionar</option>
                            <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($pais->id_pais); ?>"
                                    <?php echo e(($docente->usuario->pais->id_pais ?? null) == $pais->id_pais ? 'selected' : ''); ?>>
                                    <?php echo e($pais->nombre_pais); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="error-message" id="error-id_pais"></small>
                    </div>

                    <label for="id_localidad">Localidad</label>
                    <div class="input-group">
                        <select name="id_localidad" id="id_localidad" disabled>
                            <option value="">Seleccionar</option>
                            <?php $__currentLoopData = $localidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($localidad->id_localidad); ?>"
                                    <?php echo e(($docente->usuario->localidad->id_localidad ?? null) == $localidad->id_localidad ? 'selected' : ''); ?>>
                                    <?php echo e($localidad->nombre_localidad); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="error-message" id="error-id_localidad"></small>
                    </div>

                    <label for="domicilio">Domicilio</label>
                    <div class="input-group">
                        <input type="text" name="domicilio" id="domicilio" value="<?php echo e($docente->usuario->domicilio ?? ''); ?>" disabled>
                        <small class="error-message" id="error-domicilio"></small>
                    </div>

                    <label for="telefono">Teléfono celular</label>
                    <div class="input-group">
                        <input type="text" name="telefono" id="telefono" value="<?php echo e($telefono?->telefono ?? ''); ?>" disabled>
                        <small class="error-message" id="error-telefono"></small>
                    </div>

                    <label for="email">E-mail</label>
                    <div class="input-group">
                        <input type="email" name="email" id="email" value="<?php echo e($docente->usuario->email); ?>" disabled>
                        <small class="error-message" id="error-email"></small>
                    </div>

                    <label for="estado">Estado</label>
                    <div class="input-group">
                        <select name="estado" id="estado" disabled>
                            <option value="Activo"   <?php echo e($docente->usuario->estado == 'Activo'   ? 'selected' : ''); ?>>Activo</option>
                            <option value="Inactivo" <?php echo e($docente->usuario->estado == 'Inactivo' ? 'selected' : ''); ?>>Inactivo</option>
                        </select>
                        <small class="error-message" id="error-estado"></small>
                    </div>

                </div>

                <!-- Tabla de materias -->
                <div class="section-divider"></div>

                <div class="materias-section">
                    <h2>Materias Asignadas</h2>

                    <?php if($docente->materias->isEmpty()): ?>
                        <p class="sin-resultados">Sin materias asignadas.</p>
                    <?php else: ?>
                        <table id="tablaMaterias" class="cursada-table">
                            <thead>
                                <tr>
                                    <th>Materia</th>
                                    <th>Carrera</th>
                                    <th>Tipo</th>
                                    <th>Situación de Revista</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $docente->materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($materia->nombre); ?></td>
                                        <td><?php echo e($materia->carrera->nombre ?? '—'); ?></td>
                                        <td><?php echo e($materia->tipoMateria->descripcion_tipo_materia ?? '—'); ?></td>
                                        <td><?php echo e($materia->pivot->situacion_revista ?? '—'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <!-- Inicio de sesión -->
                <div class="section-divider"></div>

                <div class="login-section">
                    <h2>Inicio de Sesión</h2>

                    <div class="form-grid">
                        <label for="nombre_usuario">Nombre de usuario</label>
                        <div class="input-group">
                            <input type="text" name="nombre_usuario" id="nombre_usuario" value="<?php echo e($docente->usuario->nombre_usuario); ?>" disabled>
                            <small class="error-message" id="error-nombre_usuario"></small>
                        </div>

                        <label for="password">Clave</label>
                        <div class="input-group">
                            <input type="password" name="password" id="password" placeholder="Dejar en blanco para no cambiar" disabled>
                            <small class="error-message" id="error-password"></small>
                        </div>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="button" class="btn-primary" id="btn-guardar" style="display:none;">
                        <i class="ri-save-line"></i> Guardar
                    </button>
                    <button type="button" class="btn-secondary" id="btn-cancelar" style="display:none;">
                        Cancelar
                    </button>
                </div>

            </form>

        </div>
    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="<?php echo e(asset('js/Secretaria/perfilEditable.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/profesoresPerfil.blade.php ENDPATH**/ ?>