<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Plan de estudio</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/planEstudio.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/Filtro.js']); ?>
</head>

<body>
    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <!-- FILA SUPERIOR: Volver + Agregar Plan a la misma altura -->
        <div class="top-actions">
            <button class="btn-modificar" type="button" onclick="window.location='<?php echo e(route('carreras.index')); ?>'">
                <i class="ri-arrow-left-line"></i>Volver
            </button>
            <button class="btn-primary" type="button" onclick="window.location.href='<?php echo e(route('planEstudio.create')); ?>'">
                Agregar Plan
            </button>
        </div>

        <h1 class="page-title">Carreras - Plan de estudio</h1>

        <!-- FILTROS — solo cliente, sin form GET -->
        <div class="card-container">
            <div class="form-grid">
                <input
                    type="text"
                    id="filtro-nombre"
                    placeholder="Buscar por plan, resolución o carrera"
                >
            </div>
        </div>

        <div class="table-container">
            <table id="tablaPlanEstudio" class="cursada-table">
                <thead>
                    <tr>
                        <th>Plan de estudio</th>
                        <th>Carrera</th>
                        <th>Años</th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $planResoluciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="celda-titulo">
                                <?php echo e($pr->plan->titulo); ?> - <?php echo e($pr->resolucion->descripcion); ?>

                            </td>
                            <td><?php echo e($pr->carrera->nombre ?? '—'); ?></td>
                            <td><?php echo e($pr->total_horas ?? '—'); ?> Años</td>
                            <td>
                                <div class="acciones-fila">
                                    <button class="btn-primary" onclick="window.location.href='<?php echo e(route('planEspacios', $pr->id_carrera)); ?>'">Espacios</button>
                                    <button class="btn-primary" onclick="window.location.href='#'">Alumnos</button>
                                    <button
                                        class="btn-modificar"
                                        type="button"
                                        onclick="window.location.href='<?php echo e(route('planEstudio.edit', $pr->id)); ?>'">
                                        <i class="ri-edit-line"></i> Modificar
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">No hay planes de estudio cargados.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/planDeEstudio.blade.php ENDPATH**/ ?>