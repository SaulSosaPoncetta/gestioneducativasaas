<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Analitico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/alumnosSec.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/analiticoAlumno.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/planEstudio.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/Filtro.js']); ?>
</head>

<body>
    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <button class="btn-modificar" type="button" onclick="window.location='<?php echo e(route('alumnos.index')); ?>'">
            <i class="ri-arrow-left-line"></i>Volver
        </button>
        <br>

        <!-- HEADER -->
        <div class="top-bar">
            
            <h1>Analítico - Juan Pérez</h1>
        </div>

        <!-- FILTROS + STATS -->
        <div class="card-container">
            <div class="analitico-top">

                <div class="form-grid">
                    
                    <select id="select-carrera">
                        <option value="1">Profesorado en Educación Primaria</option>
                        <option value="2">Tecnicatura en Informática</option>
                    </select>
                </div>

                <div class="analitico-stats">

                    <div class="stat-item">
                        <span class="stat-label">Espacios acreditados:</span>
                        
                        <span class="stat-numero" id="espacios-acreditados">0</span>
                    </div>

                    <div class="stat-item stat-progreso">
                        <span class="stat-label">Porcentaje de la carrera:</span>
                        <div class="progress-ring" id="progress-ring">
                            <svg viewBox="0 0 120 120">
                                <circle class="progress-ring-bg" cx="60" cy="60" r="52"></circle>
                                <circle class="progress-ring-fill" id="progress-ring-fill" cx="60" cy="60" r="52"></circle>
                            </svg>
                            <span class="progress-ring-text" id="progress-ring-text">0%</span>
                        </div>
                        
                    </div>

                </div>

            </div>
        </div>

        

        <h2 class="anio-titulo">Año 1</h2>
        <div class="table-container">
            <table class="cursada-table">
                <thead>
                    <tr>
                        <th>Espacio Curricular</th>
                        <th>Cursada</th>
                        <th>Acreditación / Final</th>
                        <th>Perfil</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Inglés I</td>
                        <td>Aprobada en 2024 - Nota: 9,00</td>
                        <td>Acreditado el 20/11/2024 - Nota: 8,00</td>
                        <td><button class="btn-primary" onclick="window.location='<?php echo e(route('materias.show', 10)); ?>'">Ver</button></td>
                    </tr>
                    <tr>
                        <td>Pedagogía</td>
                        <td>Aprobada en 2024 - Nota: 7,50</td>
                        <td>Acreditado el 02/12/2024 - Nota: 7,00</td>
                        <td><button class="btn-primary" onclick="window.location='<?php echo e(route('materias.show', 11)); ?>'">Ver</button></td>
                    </tr>
                    <tr>
                        <td>Matemática I</td>
                        <td>Regular en 2024 - Nota: 6,00</td>
                        <td>Pendiente</td>
                        <td><button class="btn-primary" onclick="window.location='<?php echo e(route('materias.show', 12)); ?>'">Ver</button></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <h2 class="anio-titulo">Año 2</h2>
        <div class="table-container">
            <table class="cursada-table">
                <thead>
                    <tr>
                        <th>Espacio Curricular</th>
                        <th>Cursada</th>
                        <th>Acreditación / Final</th>
                        <th>Perfil</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Didáctica General</td>
                        <td>Aprobada en 2025 - Nota: 8,00</td>
                        <td>Acreditado el 10/06/2025 - Nota: 8,00</td>
                        <td><button class="btn-primary" onclick="window.location='<?php echo e(route('materias.show', 20)); ?>'">Ver</button></td>
                    </tr>
                    <tr>
                        <td>Psicología Educacional</td>
                        <td>Sin cursar</td>
                        <td>Pendiente</td>
                        <td><button class="btn-primary" onclick="window.location='<?php echo e(route('materias.show', 21)); ?>'">Ver</button></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <button class="btn-primary" type="button" onclick="window.print()">
            <i class="ri-printer-fill"></i> Imprimir
        </button>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="<?php echo e(asset('js/Secretaria/analiticoAlumno.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/analitico.blade.php ENDPATH**/ ?>