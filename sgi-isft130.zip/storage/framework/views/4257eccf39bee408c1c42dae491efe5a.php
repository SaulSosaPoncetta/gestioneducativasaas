<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Modificar Plan de Estudio</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/planEstudio.css')); ?>">
</head>

<body>
<button class="mobile-menu-btn" id="menu-btn">
    <i class="ri-menu-line"></i>
</button>
<?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="main">

    <!-- Volver fuera de .form-container: mismo nivel que en el listado -->
    <div class="top-actions">
        <button class="btn-modificar" type="button" onclick="window.location='<?php echo e(route('planEstudio.index')); ?>'">
            <i class="ri-arrow-left-line"></i>Volver
        </button>
    </div>

    <div class="form-container">

        <div class="perfil-header">
            <h1>Modificar Plan de Estudio</h1>
        </div>

        <div id="alerta-ajax" class="alert" style="display:none;"></div>

        <form class="materia-form" id="form-plan-estudio" enctype="multipart/form-data">
            <input type="hidden" name="_method" value="PUT">

            <div class="form-grid">

                <label for="titulo">Título del plan *</label>
                <div class="input-group">
                    <input type="text" name="titulo" id="titulo" value="<?php echo e($planResolucion->plan->titulo); ?>">
                    <small class="error-message" id="error-titulo"></small>
                </div>

                <label for="plan_descripcion">Descripción del plan</label>
                <div class="input-group">
                    <input type="text" name="plan_descripcion" id="plan_descripcion" value="<?php echo e($planResolucion->plan->descripcion); ?>">
                    <small class="error-message" id="error-plan_descripcion"></small>
                </div>

                <label for="id_carrera">Carrera *</label>
                <div class="input-group">
                    <select name="id_carrera" id="id_carrera">
                        <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($carrera->id_carrera); ?>" <?php echo e($carrera->id_carrera == $planResolucion->id_carrera ? 'selected' : ''); ?>>
                                <?php echo e($carrera->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small class="error-message" id="error-id_carrera"></small>
                </div>

                <label for="total_horas">Años de duración *</label>
                <div class="input-group">
                    <input type="number" name="total_horas" id="total_horas" value="<?php echo e($planResolucion->total_horas); ?>" min="1">
                    <small class="error-message" id="error-total_horas"></small>
                </div>

            </div>

            <div class="section-divider"></div>

            <div class="login-section">
                <h2>Resolución</h2>
                <div class="form-grid">

                    <label for="resolucion_descripcion">Resolución *</label>
                    <div class="input-group">
                        <input type="text" name="resolucion_descripcion" id="resolucion_descripcion" value="<?php echo e($planResolucion->resolucion->descripcion); ?>">
                        <small class="error-message" id="error-resolucion_descripcion"></small>
                    </div>

                    <label for="fecha">Fecha *</label>
                    <div class="input-group">
                        <input type="date" name="fecha" id="fecha" value="<?php echo e($planResolucion->fecha?->format('Y-m-d')); ?>">
                        <small class="error-message" id="error-fecha"></small>
                    </div>

                </div>
            </div>

            <div class="section-divider"></div>

            <div class="login-section">
                <h2>Archivo</h2>
                <div class="form-grid">

                    <label for="archivo_descripcion">Descripción del archivo *</label>
                    <div class="input-group">
                        <input type="text" name="archivo_descripcion" id="archivo_descripcion" value="<?php echo e($planResolucion->tipoArchivo->descripcion ?? ''); ?>">
                        <small class="error-message" id="error-archivo_descripcion"></small>
                    </div>

                    <label for="archivo">
                        Reemplazar archivo (PDF)
                        <?php if($planResolucion->tipoArchivo?->archivo): ?>
                            — <a href="<?php echo e(Storage::url($planResolucion->tipoArchivo->archivo)); ?>" target="_blank">ver actual</a>
                        <?php endif; ?>
                    </label>
                    <div class="input-group">
                        <input type="file" name="archivo" id="archivo" accept="application/pdf">
                        <small class="error-message" id="error-archivo"></small>
                    </div>

                </div>
            </div>

            <div class="form-actions">
                
                <button type="button" class="btn-primary" id="btn-guardar">
                    <i class="ri-save-line"></i> Guardar cambios
                </button>
            </div>

        </form>

    </div>
</div>

<?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<script>
(function () {
    const form       = document.getElementById('form-plan-estudio');
    const btnGuardar = document.getElementById('btn-guardar');
    const csrf       = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    const alerta     = document.getElementById('alerta-ajax');

    function mostrarAlerta(mensaje, tipo) {
        alerta.className = 'alert alert-' + tipo;
        alerta.textContent = mensaje;
        alerta.style.display = 'block';
        alerta.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function limpiarErrores() {
        form.querySelectorAll('.error-message').forEach(el => el.textContent = '');
        form.querySelectorAll('.input-error').forEach(el => el.classList.remove('input-error'));
    }

    btnGuardar.addEventListener('click', function () {
        limpiarErrores();
        btnGuardar.disabled = true;
        btnGuardar.innerHTML = '<i class="ri-loader-4-line"></i> Guardando...';

        const formData = new FormData(form);

        fetch('<?php echo e(route('planEstudio.update', [$planResolucion->id_plan, $planResolucion->id_resolucion, $planResolucion->id_carrera])); ?>', {
            method: 'POST', // spoofed a PUT via _method
            headers: {
                'X-CSRF-TOKEN': csrf,
                'Accept': 'application/json',
            },
            body: formData,
        })
        .then(r => r.json().then(data => ({ status: r.status, data })))
        .then(({ data }) => {
            btnGuardar.disabled = false;
            btnGuardar.innerHTML = '<i class="ri-save-line"></i> Guardar cambios';

            if (data.success) {
                mostrarAlerta('✓ ' + data.message, 'success');
                setTimeout(() => { window.location.href = '<?php echo e(route('planEstudio.index')); ?>'; }, 800);
            } else if (data.errors) {
                Object.entries(data.errors).forEach(([campo, mensajes]) => {
                    const input = document.getElementById(campo);
                    if (input) input.classList.add('input-error');
                    const error = document.getElementById('error-' + campo);
                    if (error) error.textContent = mensajes[0];
                });
                mostrarAlerta('Hay campos con errores. Revisá el formulario.', 'error');
            } else {
                mostrarAlerta(data.message || 'Ocurrió un error.', 'error');
            }
        })
        .catch(() => {
            btnGuardar.disabled = false;
            btnGuardar.innerHTML = '<i class="ri-save-line"></i> Guardar cambios';
            mostrarAlerta('Error de conexión. Intentá de nuevo.', 'error');
        });
    });
})();
</script>
</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/planEstudioModificar.blade.php ENDPATH**/ ?>