<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Datos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/profesoresAgregar.css')); ?>">
</head>

<body>
    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">
        <div class="form-container">

            <div class="perfil-header">
                <div><h1>Mis Datos</h1></div>
            </div>

            <div id="alert-ajax" class="alert" style="display:none;"></div>

            <?php $primerDni = $usuario->dnis->first(); ?>

            <form class="alumno-form" id="form-perfil">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-grid">

                    <label>Apellido</label>
                    <input type="text" name="apellido" value="<?php echo e($usuario->apellido); ?>" disabled>

                    <label>Nombre</label>
                    <input type="text" name="nombre" value="<?php echo e($usuario->nombre); ?>" disabled>

                    <label>Fecha de nacimiento</label>
                    <input type="date" name="fecha_nacimiento"
                        value="<?php echo e($usuario->fecha_nacimiento ? \Carbon\Carbon::parse($usuario->fecha_nacimiento)->format('Y-m-d') : ''); ?>"
                        disabled>


                    <label>Tipo de documento</label>
                    <select name="id_tipo_dni" id="id_tipo_dni" disabled>
                        <?php $__currentLoopData = $tiposDni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($tipo->id_tipo_dni); ?>"
                                <?php echo e(($primerDni?->id_tipo_dni == $tipo->id_tipo_dni) ? 'selected' : ''); ?>>
                                <?php echo e($tipo->descripcion); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label>Documento</label>
                    <input type="text" name="dni" value="<?php echo e($primerDni?->dni ?? ''); ?>" disabled>

                    <label>CUIL/CUIT</label>
                    <input type="text" name="cuil" value="<?php echo e($primerDni?->cuil ?? ''); ?>" disabled>

                    <label>Nacionalidad</label>
                    <select name="id_pais" disabled>
                        <option value="">Seleccionar</option>
                        <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pais->id_pais); ?>"
                                <?php echo e($usuario->id_pais == $pais->id_pais ? 'selected' : ''); ?>>
                                <?php echo e($pais->nombre_pais); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <label>Localidad</label>
                    <select name="id_localidad" disabled>
                        <option value="">Seleccionar</option>
                        <?php $__currentLoopData = $localidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($loc->id_localidad); ?>"
                                <?php echo e($usuario->id_localidad == $loc->id_localidad ? 'selected' : ''); ?>>
                                <?php echo e($loc->nombre_localidad); ?>

                                <?php if($loc->pais): ?> (<?php echo e($loc->pais->nombre_pais); ?>) <?php endif; ?>
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <label>Domicilio</label>
                    <input type="text" name="domicilio" value="<?php echo e($usuario->domicilio ?? ''); ?>" disabled>

                    <label>Teléfono celular</label>
                    <input type="text" name="telefono_celular"
                        value="<?php echo e($usuario->telefonos->get(0)->telefono ?? ''); ?>" disabled>

                    <label>E-mail</label>
                    <input type="email" name="email" value="<?php echo e($usuario->email); ?>" disabled>

                    <label>Género</label>
                    <select name="genero" disabled>
                        <option value="M"    <?php echo e($usuario->genero === 'M'    ? 'selected' : ''); ?>>Masculino</option>
                        <option value="F"    <?php echo e($usuario->genero === 'F'    ? 'selected' : ''); ?>>Femenino</option>
                        <option value="Otro" <?php echo e($usuario->genero === 'Otro' ? 'selected' : ''); ?>>Otro</option>
                    </select>

                </div>
            </form>
        </div>
    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Estudiante/misDatos.blade.php ENDPATH**/ ?>