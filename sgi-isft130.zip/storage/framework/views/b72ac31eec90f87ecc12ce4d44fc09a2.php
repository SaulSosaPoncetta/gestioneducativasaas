<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Carreras</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/carreraSec.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/Filtro.js']); ?>
</head>

<body>
    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <!-- HEADER -->
        <div class="top-bar">
            <h1>Carreras</h1>
            <button class="btn-primary" onclick="window.location.href='<?php echo e(route('carreras.create')); ?>'">Agregar Carrera</button>
        </div>

        <!-- BOTONES DE ACCIÓN SECUNDARIOS -->
        <div class="action-buttons">
            <button class="btn-primary" onclick="window.location.href='<?php echo e(route('planDeEstudio.index')); ?>'">Plan de estudio</button>
        </div>

        <!-- FILTROS — solo cliente, sin form GET -->
        <div class="card-container">
            <div class="form-grid">

                <input
                    type="text"
                    id="filtro-nombre"
                    placeholder="Buscar por nombre o título..."
                >

            </div>
        </div>

        <div class="table-container">

            <?php if($carreras->count() > 0): ?>

                <table id="tablaCarreras" class="cursada-table">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Título</th>
                            <th>Plan de estudios</th>
                            <th>Carrera</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($carrera->nombre); ?></td>
                                <td><?php echo e($carrera->titulo); ?></td>
                                <td>
                                    <?php if($carrera->planResolucion): ?>
                                        <?php echo e($carrera->planResolucion->resolucion->descripcion ?? '—'); ?> — <?php echo e($carrera->planResolucion->plan->titulo ?? '—'); ?>

                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button
                                        class="btn-primary"
                                        onclick="window.location.href='<?php echo e(route('carreras.show', $carrera->id_carrera)); ?>'">
                                        Ver
                                    </button>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            <?php else: ?>

                <div class="table-placeholder">
                    <i class="ri-booklet-line"></i>
                    <p>No hay carreras cargadas. Usá <strong>Agregar</strong> para crear la primera.</p>
                </div>

            <?php endif; ?>

        </div>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="overlay" id="overlay"></div>

    <!-- recargar la pagina al volver para atras, por si hay modificaciones -->
    <script>
        (function () {
            window.addEventListener('pageshow', function (event) {
                if (event.persisted) {
                    window.location.reload();
                }

                const perfEntries = performance.getEntriesByType("navigation");

                if (perfEntries.length > 0 && perfEntries[0].type === "back_forward") {
                    window.location.reload();
                }
            });
        })();
    </script>

</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/carreraSec.blade.php ENDPATH**/ ?>