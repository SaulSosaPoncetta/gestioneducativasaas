<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Recuperar contraseña</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/log.css')); ?>">
</head>
<body>

    <div class="top">
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo">
    </div>

    <main>
        <div class="container">

            <h2 class="form-title">Recuperar contraseña</h2>
            <p class="form-subtitle">Ingresá tu email y te enviaremos un link para restablecer tu contraseña.</p>

            
            <?php if(session('status')): ?>
                <div class="success-msg">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            
            <?php if($errors->any()): ?>
                <div class="error-msg">
                    <?php echo e($errors->first('email')); ?>

                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('password.email')); ?>">
                <?php echo csrf_field(); ?>

                <input
                    type="email"
                    name="email"
                    placeholder="Ingresá tu email"
                    value="<?php echo e(old('email')); ?>"
                    required
                    autofocus
                >

                <button type="submit">Enviar link de recuperación</button>

                <a href="<?php echo e(route('login')); ?>" class="back-link">Volver al login</a>
            </form>
        </div>
    </main>

    <footer>
        <p>@2027 - SGI</p>
    </footer>

</body>
</html><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\sgi-isft130\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>