<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscar profesor</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/profesoresSec.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/alumnosSec.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/Filtro.js']); ?>
</head>

<body>
<button class="mobile-menu-btn" id="menu-btn">
    <i class="ri-menu-line"></i>
</button>
<?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="main">

    <!-- HEADER -->
    <div class="top-bar">
        <h1>Buscar Profesor</h1>
        <button class="btn-primary" onclick="window.location.href='<?php echo e(route('profesoresAgregar')); ?>'">Agregar Profesor</button>
    </div>

    <!-- FILTROS -->
    <form method="GET" action="<?php echo e(route('profesoresSec')); ?>">
        <div class="card-container">
            <div class="form-grid">

                <input type="text" id="buscador-profesores" placeholder="Buscar por nombre, apellido o DNI..." name="nombre_apellido">

                <select id="filtro-estado" name="estado">
                    <option disabled selected hidden>Estado</option>
                    <option value="">Todos</option>
                    <option value="Activo">Activo</option>
                    <option value="Inactivo">Inactivo</option>
                </select>

            </div>
        </div>
    </form>

    <div class="table-container">

        <table id="tablaDocentes" class="cursada-table">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>DNI</th>
                    <th>Estado</th>
                    <th>Teléfono</th>
                    <th>Perfil</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($docente->usuario->nombre); ?> <?php echo e($docente->usuario->apellido); ?>

                        </td>
                        <td>
                            <?php echo e($docente->usuario->dnis->first()->dni ?? 'Sin DNI'); ?>

                        </td>
                        <td>
                            <?php echo e($docente->usuario->estado ?? '—'); ?>

                        </td>
                        <td>
                            <?php echo e($docente->usuario->telefonos->first()->telefono ?? 'Sin teléfono'); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('docentes.show', $docente->id_usuario)); ?>">
                                <button class="btn-primary" type="button">Ver</button>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- recargar la pagina al volver para atras si estás en el perfil, por si hay modificaciones -->
    <script>
        (function () {
            window.addEventListener('pageshow', function(event){
                if (event.persisted){
                    window.location.reload();
                }

                const perfEntries = performance.getEntriesByType("navigation");

                if (perfEntries.length > 0 && perfEntries[0].type === "back_forward"){
                    window.location.reload();
                }
            });
        })();
    </script>

</body>
</html><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\sgi-isft130\resources\views/Secretaria/profesoresSec.blade.php ENDPATH**/ ?>