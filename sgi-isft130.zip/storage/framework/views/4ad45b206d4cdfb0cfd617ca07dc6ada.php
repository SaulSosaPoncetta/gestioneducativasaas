<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Fecha</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/cargarNota.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>

<body>
<button class="mobile-menu-btn" id="menu-btn">
    <i class="ri-menu-line"></i>
</button>
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">
        <button class="btn-modificar" type="button" onclick="window.location='<?php echo e(route('finalesSec')); ?>'">
            <i class="ri-arrow-left-line"></i>Volver
        </button>

        <div class="perfil-header">
            <h1>Mesa de final</h1>

            <div class="header-actions">
                <button class="btn-modificar" id="btn-modificar" type="button">
                    <i class="ri-edit-line"></i> Modificar
                </button>
                <button class="btn-primary" onclick="window.location.href='<?php echo e(route('finalesAgregarEst', $mesa->id_mesa)); ?>'">Agregar alumno</button>
                <button class="btn-primary" onclick="window.location.href='<?php echo e(route('cargarNotasFinal', $mesa->id_mesa)); ?>'">Subir Nota</button>
            </div>
        </div>

        <div id="alert-ajax" class="alert" style="display:none;"></div>

        <div class="form-grid" style="max-width:600px; margin-bottom:24px;">

            <label>Espacio</label>
            <span><?php echo e($mesa->espacio); ?></span>

            <label>Fecha</label>
            <span><?php echo e($mesa->fecha); ?></span>

            <label>Presidente de mesa</label>
            <span><?php echo e($mesa->presidente_mesa); ?></span>

            <label>Vocales</label>
            <span><?php echo e(implode(', ', $mesa->vocales)); ?></span>

            <label>N° Aula</label>
            <span><?php echo e($mesa->aula); ?></span>

        </div>

        <?php if($alumnosFinal->isEmpty()): ?>

            <div class="empty-state">
                <i class="ri-user-line"></i>
                <p>Todavía no hay estudiantes agregados a esta mesa.</p>
            </div>

        <?php else: ?>

        <form id="form-mesa-final">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="table-container">
                <table class="cursada-table" id="tablaMesaFinal">
                    <thead>
                        <tr>
                            <th>Alumno</th>
                            <th style="width:140px;">Nota</th>
                            <th style="width:100px;">Intentos</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $alumnosFinal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($alumno->nombre); ?></td>
                            <td class="nota-cell">
                                <input
                                    type="number"
                                    class="nota-input"
                                    name="nota_<?php echo e($alumno->id_usuario); ?>"
                                    id="nota_<?php echo e($alumno->id_usuario); ?>"
                                    value="<?php echo e($alumno->nota); ?>"
                                    min="1"
                                    max="10"
                                    step="0.01"
                                    disabled
                                >
                                <small class="error-message" id="error-nota_<?php echo e($alumno->id_usuario); ?>"></small>
                            </td>
                            <td><?php echo e($alumno->cant); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <div style="display:flex; justify-content:flex-start; gap:10px; margin-top:12px;">
                <button type="button" class="btn-primary" id="btn-guardar" style="display:none;">
                    <i class="ri-save-line"></i> Guardar
                </button>
                <button type="button" class="btn-secondary" id="btn-cancelar" style="display:none;">
                    Cancelar
                </button>
            </div>

        </form>

        <?php endif; ?>

        <button type="button" class="btn-table" id="btn-imprimir" title="Imprimir mesa" style="width:44px; height:44px; margin-top:20px;">
            <i class="ri-printer-line"></i>
        </button>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
    document.addEventListener('DOMContentLoaded', function () {

        const btnModificar = document.getElementById('btn-modificar');
        const btnGuardar   = document.getElementById('btn-guardar');
        const btnCancelar  = document.getElementById('btn-cancelar');
        const btnImprimir  = document.getElementById('btn-imprimir');
        const alertAjax    = document.getElementById('alert-ajax');

        // Si no hay estudiantes cargados, estos botones no existen en el DOM.
        if (!btnModificar || !btnGuardar || !btnCancelar) {
            if (btnImprimir) {
                btnImprimir.addEventListener('click', function () {
                    window.print();
                });
            }
            return;
        }

        // Solo las notas son editables; el resto de la mesa es informativo
        const notaInputs = Array.from(document.querySelectorAll('.nota-input'));

        let valoresOriginales = {};

        function guardarValoresOriginales() {
            notaInputs.forEach(function (input) {
                valoresOriginales[input.name] = input.value;
            });
        }

        function restaurarValoresOriginales() {
            notaInputs.forEach(function (input) {
                input.value = valoresOriginales[input.name] ?? '';
            });
        }

        function habilitarEdicion() {
            notaInputs.forEach(function (input) {
                input.disabled = false;
            });
            btnModificar.innerHTML = '<i class="ri-edit-line"></i> Editando...';
            btnModificar.classList.add('btn-editing');
            btnGuardar.style.display  = '';
            btnCancelar.style.display = '';
        }

        function deshabilitarEdicion() {
            notaInputs.forEach(function (input) {
                input.disabled = true;
            });
            btnModificar.innerHTML = '<i class="ri-edit-line"></i> Modificar';
            btnModificar.classList.remove('btn-editing');
            btnGuardar.style.display  = 'none';
            btnCancelar.style.display = 'none';
        }

        function mostrarAlerta(mensaje, tipo) {
            alertAjax.textContent = mensaje;
            alertAjax.className = 'alert alert-' + tipo;
            alertAjax.style.display = 'block';

            alertAjax.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest'
            });

            if (tipo === 'success') {
                setTimeout(function () {
                    alertAjax.style.display = 'none';
                }, 5000);
            }
        }

        function limpiarErrores() {
            document.querySelectorAll('.error-message').forEach(function (error) {
                error.textContent = '';
            });
            document.querySelectorAll('.input-error').forEach(function (input) {
                input.classList.remove('input-error');
            });
        }

        guardarValoresOriginales();

        btnModificar.addEventListener('click', function () {
            habilitarEdicion();
        });

        btnCancelar.addEventListener('click', function () {
            restaurarValoresOriginales();
            deshabilitarEdicion();
            limpiarErrores();
            alertAjax.style.display = 'none';
        });

        notaInputs.forEach(function (input) {
            input.addEventListener('input', function () {
                input.classList.remove('input-error');
                const error = document.getElementById('error-' + input.id);
                if (error) {
                    error.textContent = '';
                }
            });
        });

        btnGuardar.addEventListener('click', function () {

            limpiarErrores();

            let hayErrores = false;

            notaInputs.forEach(function (input) {
                const valor = input.value.trim();

                if (valor === '') {
                    return;
                }

                const numero = Number(valor);

                if (Number.isNaN(numero) || numero < 1 || numero > 10) {
                    input.classList.add('input-error');
                    const error = document.getElementById('error-' + input.id);
                    if (error) {
                        error.textContent = 'La nota debe ser un número entre 1 y 10.';
                    }
                    hayErrores = true;
                }
            });

            if (hayErrores) {
                mostrarAlerta('Hay notas con errores. Revisá el formulario.', 'error');
                return;
            }

            btnGuardar.disabled = true;
            btnGuardar.innerHTML = '<i class="ri-loader-4-line"></i> Guardando...';

            const datos = {};
            notaInputs.forEach(function (input) {
                datos[input.name] = input.value;
            });

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch('/mesaFinalPerfil/<?php echo e($mesa->id_mesa); ?>', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'Accept': 'application/json',
                },
                body: JSON.stringify(datos),
            })
            .then(function (response) {
                return response.json().then(function (data) {
                    return { status: response.status, data: data };
                });
            })
            .then(function ({ status, data }) {

                btnGuardar.disabled = false;
                btnGuardar.innerHTML = '<i class="ri-save-line"></i> Guardar';

                if (data.success) {

                    guardarValoresOriginales();
                    deshabilitarEdicion();
                    mostrarAlerta('✓ ' + data.message, 'success');

                } else {

                    if (data.errors) {

                        Object.entries(data.errors).forEach(function ([campo, errores]) {

                            const input = document.getElementById(campo);
                            if (input) {
                                input.classList.add('input-error');
                            }

                            const error = document.getElementById('error-' + campo);
                            if (error) {
                                error.textContent = errores[0];
                            }

                        });

                        mostrarAlerta('Hay campos con errores. Revisá el formulario.', 'error');

                    } else {

                        mostrarAlerta(data.message || 'Ocurrió un error.', 'error');

                    }
                }

            })
            .catch(function () {
                btnGuardar.disabled = false;
                btnGuardar.innerHTML = '<i class="ri-save-line"></i> Guardar';
                mostrarAlerta('Error de conexión. Intentá de nuevo.', 'error');
            });

        });

        // ─── Imprimir ────────────────────────────────────────────────
        btnImprimir.addEventListener('click', function () {
            window.print();
        });

    });
    </script>

</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/finalPerfil.blade.php ENDPATH**/ ?>