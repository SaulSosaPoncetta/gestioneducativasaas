<div class="sidebar">

    <div>
        <div class="top-icons">
            <i class="ri-logout-box-r-line"
               id="logout-icon"
               title="Cerrar sesión"
               style="cursor:pointer"></i>
        </div>

        <form method="POST" action="<?php echo e(route('logout')); ?>" id="logout-form" class="d-none">
            <?php echo csrf_field(); ?>
        </form>

        <div class="profile">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo">
        </div>

        <div class="menu">

            <?php switch(auth()->user()->rol->descripcion):

            
            
            

            case ('Administrador'): ?>
            <?php case ('Secretario'): ?>

                <a href="<?php echo e(route('carreras.index')); ?>">
                    <i class="ri-book-line"></i> Carrera
                </a>

                <a href="<?php echo e(route('cicloLectivoSec')); ?>">
                    <i class="ri-calendar-line"></i> Ciclo Lectivo
                </a>

                <a href="<?php echo e(route('finalesSec')); ?>">
                    <i class="ri-award-line"></i> Finales
                </a>

                <div class="menu-item-dropdown">

                    <a href="#" class="dropdown-toggle" id="usuarios-toggle">
                        <i class="ri-user-line"></i> Usuarios
                        <i class="ri-arrow-right-s-line dropdown-arrow"></i>
                    </a>

                    <div class="dropdown-submenu" id="usuarios-submenu">

                        <a href="<?php echo e(route('alumnos.index')); ?>">
                            Alumnos
                        </a>

                        <a href="<?php echo e(route('profesoresSec')); ?>">
                            Profesores
                        </a>

                        <a href="<?php echo e(route('administracionSec')); ?>">
                            Administradores
                        </a>

                    </div>

                </div>

                <a href="#">
                    <i class="ri-graduation-cap-line"></i> Egresados
                </a>

                <a href="<?php echo e(route('auditoria')); ?>">
                    <i class="ri-history-line"></i> Auditoría
                </a>

                <a href="<?php echo e(route('misdatos')); ?>">
                    <i class="ri-home-line"></i> Mis datos
                </a>

            <?php break; ?>


            
            
            
            <?php case ('Estudiante'): ?>

                <a href="<?php echo e(route('carreraEst')); ?>">
                    <i class="ri-book-line"></i> Carrera
                </a>

                <a href="#">
                    <i class="ri-calendar-line"></i> Cursada
                </a>

                <a href="#">
                    <i class="ri-award-line"></i> Finales
                </a>

                <a href="#">
                    <i class="ri-clipboard-line"></i>Analitico
                </a>

                <a href="<?php echo e(route('misdatos.estudiante')); ?>">
                    <i class="ri-home-line"></i> Mis datos
                </a>

            <?php break; ?>


            
            
            
            <?php case ('Docente'): ?>

                <a href="#">
                    <i class="ri-book-line"></i> Materias
                </a>

                <a href="#">
                    <i class="ri-award-line"></i> Finales
                </a>

                <a href="<?php echo e(route('misdatos')); ?>">
                    <i class="ri-home-line"></i> Mis datos
                </a>
            <?php break; ?>

        <?php endswitch; ?>

        </div>

    </div>

</div>

<div class="overlay" id="overlay"></div>

<script src="<?php echo e(asset('js/sidebar.js')); ?>"></script>
<script>
document.getElementById('logout-icon').addEventListener('click', function () {
    document.getElementById('logout-form').submit();
});
</script>
<?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>