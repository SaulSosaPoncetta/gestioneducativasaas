<footer>
    <pre>@2027 - SGI</pre>
</footer><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\sgi-isft130\resources\views/partials/footer.blade.php ENDPATH**/ ?>