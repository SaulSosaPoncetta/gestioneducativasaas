<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inscripción a finales</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/alumnosSec.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Estudiante/finalesInscripcion.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body>
    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <button class="btn-modificar" type="button" onclick="window.location='<?php echo e(route('finales')); ?>'">
            <i class="ri-arrow-left-line"></i>Volver
        </button>

        <br>

        <!-- HEADER -->
        <div class="top-bar">
            <h1>Inscripcion a finales</h1>
        </div>

        

        <div class="table-container anio-container">
            <table class="cursada-table tabla-inscripcion-anio">
                <thead>
                    <tr>
                        <th class="col-espacio">
                            <span>Espacio Curricular</span>
                            <span class="anio-badge">1° AÑO</span>
                        </th>
                        <th>Condición</th>
                        <th>Fechas</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="fila-bloqueada">
                        <td>Inglés I</td>
                        <td>Regular</td>
                        <td></td>
                    </tr>
                    <tr class="fila-bloqueada">
                        <td>Análisis Matemático I</td>
                        <td>Regular</td>
                        <td></td>
                    </tr>
                    <tr class="fila-bloqueada">
                        <td>Ciencia, Tecnología y Sociedad</td>
                        <td>Regular</td>
                        <td></td>
                    </tr>
                    <tr class="fila-bloqueada">
                        <td>Álgebra</td>
                        <td>Regular</td>
                        <td></td>
                    </tr>
                    <tr class="fila-bloqueada">
                        <td>Prácticas Profesionalizantes I</td>
                        <td>Regular</td>
                        <td></td>
                    </tr>
                    <tr class="fila-bloqueada">
                        <td>Algoritmos y estructuras de datos I</td>
                        <td>Libre</td>
                        <td></td>
                    </tr>
                    <tr class="fila-bloqueada">
                        <td>Sistemas y Organizaciones</td>
                        <td>Regular</td>
                        <td></td>
                    </tr>
                    <tr class="fila-bloqueada">
                        <td>Arquitectura de Computadoras</td>
                        <td>Regular</td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="table-container anio-container">
            <table class="cursada-table tabla-inscripcion-anio">
                <thead>
                    <tr>
                        <th class="col-espacio">
                            <span>Espacio Curricular</span>
                            <span class="anio-badge">2° AÑO</span>
                        </th>
                        <th>Condición</th>
                        <th>Fechas</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Inglés I</td>
                        <td>Regular</td>
                        <td>
                            <div class="fechas-row">
                                <button type="button" class="btn-fecha" data-id-mesa="101">17/12/25 18:10</button>
                                <button type="button" class="btn-fecha" data-id-mesa="102">10/01/25 20:15</button>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Análisis Matemático I</td>
                        <td>Regular</td>
                        <td>
                            <div class="fechas-row">
                                <button type="button" class="btn-fecha" data-id-mesa="103">17/12/25 18:10</button>
                                <button type="button" class="btn-fecha" data-id-mesa="104">10/01/25 20:15</button>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Ciencia, Tecnología y Sociedad</td>
                        <td>Regular</td>
                        <td>
                            <div class="fechas-row">
                                <button type="button" class="btn-fecha" data-id-mesa="105">17/12/25 18:10</button>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Álgebra</td>
                        <td>Regular</td>
                        <td>
                            <div class="fechas-row">
                                <button type="button" class="btn-fecha" data-id-mesa="106">17/12/25 18:10</button>
                                <button type="button" class="btn-fecha" data-id-mesa="107">10/01/25 20:15</button>
                            </div>
                        </td>
                    </tr>
                    <tr class="fila-bloqueada">
                        <td>Prácticas Profesionalizantes I</td>
                        <td>Regular</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Algoritmos y estructuras de datos I</td>
                        <td>Libre</td>
                        <td>
                            <div class="fechas-row">
                                <button type="button" class="btn-fecha" data-id-mesa="108">17/12/25 18:10</button>
                                <button type="button" class="btn-fecha" data-id-mesa="109">10/01/25 20:15</button>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Sistemas y Organizaciones</td>
                        <td>Libre</td>
                        <td>
                            <div class="fechas-row">
                                <button type="button" class="btn-fecha" data-id-mesa="110">17/12/25 18:10</button>
                                <button type="button" class="btn-fecha" data-id-mesa="111">10/01/25 20:15</button>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        
        <div class="form-actions">
            <button type="button" class="btn-primary" id="btn-guardar-inscripcion">
                <i class="ri-save-line"></i> Guardar
            </button>
        </div>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
        window.rutaFinalesSec = '<?php echo e(route('finales')); ?>';
    </script>
    <script src="<?php echo e(asset('js/Estudiante/finalesInscripcion.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Estudiante/finalesInscripcion.blade.php ENDPATH**/ ?>