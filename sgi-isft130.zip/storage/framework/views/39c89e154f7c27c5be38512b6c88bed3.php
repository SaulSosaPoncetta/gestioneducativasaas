<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cargar notas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/cargarNota.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/Filtro.js']); ?>

</head>

<body>
<button class="mobile-menu-btn" id="menu-btn">
    <i class="ri-menu-line"></i>
</button>
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php
        $periodos = ['1C' => '1° C', '2C' => '2° C', 'REC' => 'Rec./Prefinal'];

        $renderCeldaNota = function ($nota) {
            $valor = $nota->valor ?? '';
            $situacion = $nota->situacion ?? '';
            $etiquetas = [
                'promocionado'      => 'Promocionado',
                'aprobado'          => 'Aprobado',
                'desaprobado'       => 'Desaprobado',
                'promocion_directa' => 'Promoción directa',
                'examen_flotante'   => 'Pendiente examen flotante',
            ];
            $etiqueta = $etiquetas[$situacion] ?? '';

            return compact('valor', 'situacion', 'etiqueta');
        };
    ?>

    <div
        class="main"
        id="app-cargar-notas"
        data-materia="<?php echo e($materia->id_materia); ?>"
        data-nota-promocionable="<?php echo e($materia->nota_promocionable ?? 7); ?>"
        data-nota-aprobada="<?php echo e($materia->nota_aprobada ?? 4); ?>"
        data-promocion-directa="<?php echo e($materia->promocionable ? '1' : '0'); ?>"
    >
        <button class="btn-modificar" type="button" onclick="window.location='<?php echo e(route('materias.show', $materia->id_materia)); ?>'">
            <i class="ri-arrow-left-line"></i>Volver
        </button>

        <h1>Cargar notas — <?php echo e($materia->nombre); ?></h1>

        <div id="alert-ajax" class="alert" style="display:none;"></div>

        <div class="top-bar">
            <label>
                Cerrar cursada Automaticamente
                <input type="checkbox" id="cierre_automatico" checked>
            </label>
            <span class="help">
                Si esta activado, la cursada se cerrara automaticamente en base a la situacion de los dos cuatrimestres. Puede cambiar los datos de cierre manualmete.
            </span>
        </div>

        <div class="table-container tabla-responsive">
            <table class="cursada-table" id="tablaCargarNotas">
                <thead>
                    <tr>
                        <th>Alumno</th>
                        <th>1° C</th>
                        <th>2° C</th>
                        <th>Rec./Prefinal</th>
                        <th>Cierre</th>
                        <th style="width:100px;">Reprobar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cursando; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-estado="cursando" data-id="<?php echo e($fila->id_usuario); ?>">
                        <td><?php echo e($fila->nombre); ?></td>

                        <?php $__currentLoopData = ['primerC' => '1C', 'segundoC' => '2C', 'recPrefinal' => 'REC']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prop => $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $c = $renderCeldaNota($fila->{$prop}); ?>
                            <td class="nota-cell" data-periodo="<?php echo e($periodo); ?>">
                                <div class="nota-wrapper dropdown" data-situacion="<?php echo e($c['situacion']); ?>">
                                    <input type="text" class="nota-input" placeholder="Nota" value="<?php echo e($c['valor']); ?>">
                                    <button type="button" class="arrow-btn btn-dropdown">›</button>
                                    <ul class="dropdown-menu-notas">
                                        <li><a class="dropdown-item opcion-nota" href="#" data-valor="promocionado">Promocionado</a></li>
                                        <li><a class="dropdown-item opcion-nota" href="#" data-valor="aprobado">Aprobado</a></li>
                                        <li><a class="dropdown-item opcion-nota" href="#" data-valor="desaprobado">Desaprobado</a></li>
                                        <?php if($periodo !== 'REC' && $materia->promocionable): ?>
                                            <li><a class="dropdown-item opcion-nota" href="#" data-valor="promocion_directa">Promoción directa</a></li>
                                        <?php endif; ?>
                                    </ul>
                                    <?php if($c['etiqueta']): ?>
                                        <span class="badge-situacion badge-<?php echo e($c['situacion']); ?>"><?php echo e($c['etiqueta']); ?></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php $cierre = $renderCeldaNota($fila->cierre); ?>
                        <td class="nota-cell" data-periodo="CIERRE">
                            <div class="nota-wrapper dropdown" data-situacion="<?php echo e($cierre['situacion']); ?>">
                                <input type="text" class="nota-input" placeholder="Nota" value="<?php echo e($cierre['valor']); ?>">
                                <button type="button" class="arrow-btn btn-dropdown">›</button>
                                <ul class="dropdown-menu-notas">
                                    <li><a class="dropdown-item opcion-nota" href="#" data-valor="promocionado">Promocionado</a></li>
                                    <li><a class="dropdown-item opcion-nota" href="#" data-valor="aprobado">Aprobado</a></li>
                                    <li><a class="dropdown-item opcion-nota" href="#" data-valor="desaprobado">Desaprobado</a></li>
                                </ul>
                                <?php if($cierre['etiqueta']): ?>
                                    <span class="badge-situacion badge-<?php echo e($cierre['situacion']); ?>"><?php echo e($cierre['etiqueta']); ?></span>
                                <?php endif; ?>
                            </div>
                        </td>

                        
                        <td class="text-center">
                            <a
                                href="#"
                                class="btn-table btn-reprobar-directo"
                                title="Reprobar alumno directamente"
                                style="background:#dc2626; text-decoration: none;">
                                <i class="ri-close-circle-line"></i>
                            </a>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div style="display:flex; justify-content:flex-start; gap:10px; margin-top:12px;">
            <button class="btn-primary" id="btn-guardar">
                <i class="ri-save-line"></i> Guardar
            </button>
        </div>

        <br>

        <h1>Alumnos desaprobados directamente</h1>

        <div class="table-container tabla-responsive">
            <table class="cursada-table" id="tablaReprobados">
                <thead>
                    <tr>
                        <th>Alumno</th>
                        <th>1° C</th>
                        <th>2° C</th>
                        <th>Rec./Prefinal</th>
                        <th style="width:100px;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $reprobados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-estado="reprobado" data-id="<?php echo e($fila->id_usuario); ?>">
                        <td><?php echo e($fila->nombre); ?></td>
                        <td><?php echo e($fila->primerC->valor ?? '—'); ?></td>
                        <td><?php echo e($fila->segundoC->valor ?? '—'); ?></td>
                        <td><?php echo e($fila->recPrefinal->valor ?? '—'); ?></td>
                        <td class="text-center">
                            <a href="#" class="btn-table btn-restaurar" title="Restaurar a cursando">
                                <i class="ri-arrow-go-back-line"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="<?php echo e(asset('js/Secretaria/cargarNota.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/cargarNota.blade.php ENDPATH**/ ?>