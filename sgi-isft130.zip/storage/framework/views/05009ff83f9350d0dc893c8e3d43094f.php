<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historial de finales</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/cursadaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/cargarNota.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>

<body>
<button class="mobile-menu-btn" id="menu-btn">
    <i class="ri-menu-line"></i>
</button>
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">
        <button class="btn-modificar" type="button" onclick="window.location='<?php echo e(route('finalesSec')); ?>'">
            <i class="ri-arrow-left-line"></i>Volver
        </button>
        <br>

        <h1>Historial de finales</h1>

        <div class="form-grid" style="max-width:600px; margin:24px 0;">

            <label for="filtro-carrera">Carrera:</label>
            <div class="input-group">
                <select id="filtro-carrera">
                    <option value="" disabled selected hidden>Seleccionar carrera</option>
                    <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($carrera->id_carrera); ?>"><?php echo e($carrera->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <label for="filtro-llamado">Llamado:</label>
            <div class="input-group">
                <select id="filtro-llamado">
                    <option value="" disabled selected hidden>Seleccionar llamado</option>
                    <?php $__currentLoopData = $llamados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $llamado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($llamado->id_llamado); ?>"><?php echo e($llamado->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <label for="filtro-anio">Año:</label>
            <div class="input-group">
                <select id="filtro-anio">
                    <option value="">Todos</option>
                    <?php $__currentLoopData = $anios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($anio); ?>"><?php echo e($anio); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

        </div>

        <div id="mensaje-seleccionar" class="empty-state">
            <i class="ri-filter-3-line"></i>
            <p>Seleccioná una carrera y un llamado para ver el historial de finales.</p>
        </div>

        <div id="tabla-historial-wrapper" style="display:none;">
            <div class="table-container">
                <table class="cursada-table" id="tablaHistorialFinales">
                <thead>
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Espacio</th>
                        <th style="width:80px;">Año</th>
                        <th>Profesores</th>
                        <th style="width:100px;">Acciones</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $mesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr
                        data-carrera="<?php echo e($mesa->id_carrera); ?>"
                        data-llamado="<?php echo e($mesa->id_llamado); ?>"
                        data-anio="<?php echo e($mesa->anio); ?>"
                    >
                        <td><?php echo e($mesa->fecha_hora); ?></td>
                        <td><?php echo e($mesa->espacio); ?></td>
                        <td><?php echo e($mesa->anio); ?>°</td>
                        <td><?php echo e($mesa->profesores); ?></td>
                        <td class="text-center">
                            <a
                                href="<?php echo e(route('finalPerfil', $mesa->id_mesa)); ?>"
                                class="btn-primary">
                                ver
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
                </table>
            </div>

            <button type="button" class="btn-table" id="btn-imprimir" title="Imprimir historial" style="width:44px; height:44px; margin-top:20px;">
                <i class="ri-printer-line"></i>
            </button>
        </div>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
    document.addEventListener('DOMContentLoaded', function () {

        const filtroCarrera = document.getElementById('filtro-carrera');
        const filtroLlamado = document.getElementById('filtro-llamado');
        const filtroAnio    = document.getElementById('filtro-anio');
        const filas         = document.querySelectorAll('#tablaHistorialFinales tbody tr');
        const btnImprimir   = document.getElementById('btn-imprimir');
        const mensajeVacio  = document.getElementById('mensaje-seleccionar');
        const tablaWrapper  = document.getElementById('tabla-historial-wrapper');

        function aplicarFiltros() {
            const carrera = filtroCarrera.value;
            const llamado = filtroLlamado.value;
            const anio    = filtroAnio.value;

            // Carrera y Llamado son obligatorios: sin los dos, no se muestra nada
            if (carrera === '' || llamado === '') {
                tablaWrapper.style.display = 'none';
                mensajeVacio.style.display = '';
                return;
            }

            tablaWrapper.style.display = '';
            mensajeVacio.style.display = 'none';

            filas.forEach(function (fila) {
                const coincide =
                    fila.dataset.carrera === carrera &&
                    fila.dataset.llamado === llamado &&
                    (anio === '' || fila.dataset.anio === anio);

                fila.style.display = coincide ? '' : 'none';
            });
        }

        [filtroCarrera, filtroLlamado, filtroAnio].forEach(function (select) {
            select.addEventListener('change', aplicarFiltros);
        });

        aplicarFiltros();

        btnImprimir.addEventListener('click', function () {
            window.print();
        });

    });
    </script>

</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/finalesHistorial.blade.php ENDPATH**/ ?>