<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Finales</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/alumnosSec.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Estudiante/finalesEst.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body>
    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">
        <!-- HEADER -->
        <div class="top-bar">
            <h1>Finales</h1>
            <button class="btn-primary" type="button" onclick="window.location.href='<?php echo e(route('finalesInscripcion')); ?>'">
                Inscripción
            </button>
        </div>

        <div class="card-container">
            <div class="form-grid finalesEst-grid">
                <label>Carrera</label>
                <select id="select-carrera-finales">
                    <option value="1">Profesorado en Educación Primaria</option>
                    <option value="2">Tecnicatura en Informática</option>
                </select>
            </div>
        </div>

        <!-- PESTAÑAS -->
        <div class="finales-tabs">
            <button class="btn-tab activo" type="button" data-tabla="inscripto">Inscripto</button>
            <button class="btn-tab" type="button" data-tabla="aprobado">Aprobado</button>
            <button class="btn-tab" type="button" data-tabla="no-aprobado">No aprobado</button>
            <button class="btn-tab" type="button" data-tabla="bajas">Bajas</button>
        </div>

        <div class="table-container" id="finales-print-area">

            <!-- Carrera 1 -->
            <table class="cursada-table tabla-finales" data-carrera="1" data-tabla="inscripto">
                <thead>
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Espacio Curricular</th>
                        <th>Año</th>
                        <th>Modalidad</th>
                        <th>Nota</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>10/03/2025 18:10 hs</td>
                        <td>Sistemas y Organizaciones</td>
                        <td>1°</td>
                        <td>Regular</td>
                        <td>—</td>
                    </tr>
                    <tr>
                        <td>24/03/2025 09:00 hs</td>
                        <td>Inglés I</td>
                        <td>1°</td>
                        <td>Libre</td>
                        <td>—</td>
                    </tr>
                </tbody>
            </table>

            <table class="cursada-table tabla-finales" data-carrera="1" data-tabla="aprobado" style="display:none;">
                <thead>
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Espacio Curricular</th>
                        <th>Año</th>
                        <th>Modalidad</th>
                        <th>Nota</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>15/11/2024 18:00 hs</td>
                        <td>Pedagogía</td>
                        <td>1°</td>
                        <td>Regular</td>
                        <td>7</td>
                    </tr>
                    <tr>
                        <td>02/12/2024 08:30 hs</td>
                        <td>Matemática I</td>
                        <td>1°</td>
                        <td>Regular</td>
                        <td>8</td>
                    </tr>
                </tbody>
            </table>

            <table class="cursada-table tabla-finales" data-carrera="1" data-tabla="no-aprobado" style="display:none;">
                <thead>
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Espacio Curricular</th>
                        <th>Año</th>
                        <th>Modalidad</th>
                        <th>Nota</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>20/07/2024 10:00 hs</td>
                        <td>Didáctica General</td>
                        <td>2°</td>
                        <td>Libre</td>
                        <td>3</td>
                    </tr>
                </tbody>
            </table>

            <table class="cursada-table tabla-finales" data-carrera="1" data-tabla="bajas" style="display:none;">
                <thead>
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Espacio Curricular</th>
                        <th>Año</th>
                        <th>Modalidad</th>
                        <th>Nota</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>05/05/2024 18:10 hs</td>
                        <td>Psicología Educacional</td>
                        <td>2°</td>
                        <td>Regular</td>
                        <td>—</td>
                    </tr>
                </tbody>
            </table>

            <!-- Carrera 2 -->
            <table class="cursada-table tabla-finales" data-carrera="2" data-tabla="inscripto" style="display:none;">
                <thead>
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Espacio Curricular</th>
                        <th>Año</th>
                        <th>Modalidad</th>
                        <th>Nota</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>18/03/2025 19:00 hs</td>
                        <td>Programación I</td>
                        <td>1°</td>
                        <td>Regular</td>
                        <td>—</td>
                    </tr>
                </tbody>
            </table>

            <table class="cursada-table tabla-finales" data-carrera="2" data-tabla="aprobado" style="display:none;">
                <thead>
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Espacio Curricular</th>
                        <th>Año</th>
                        <th>Modalidad</th>
                        <th>Nota</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>12/12/2023 18:00 hs</td>
                        <td>Bases de Datos</td>
                        <td>1°</td>
                        <td>Regular</td>
                        <td>9</td>
                    </tr>
                </tbody>
            </table>

            <table class="cursada-table tabla-finales" data-carrera="2" data-tabla="no-aprobado" style="display:none;">
                <thead>
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Espacio Curricular</th>
                        <th>Año</th>
                        <th>Modalidad</th>
                        <th>Nota</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="5" class="sin-resultados">Sin registros</td>
                    </tr>
                </tbody>
            </table>

            <table class="cursada-table tabla-finales" data-carrera="2" data-tabla="bajas" style="display:none;">
                <thead>
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Espacio Curricular</th>
                        <th>Año</th>
                        <th>Modalidad</th>
                        <th>Nota</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="5" class="sin-resultados">Sin registros</td>
                    </tr>
                </tbody>
            </table>

        </div>

        <button type="button" class="btn-table ri-printer-line" id="btn-imprimir" title="Imprimir tabla"></button>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="<?php echo e(asset('js/Estudiante/finalesEst.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Estudiante/finales.blade.php ENDPATH**/ ?>