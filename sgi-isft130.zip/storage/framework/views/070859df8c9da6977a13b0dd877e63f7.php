<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Final</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/alumnosSec.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/agregarFinal.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/Filtro.js']); ?>
</head>

<body>
    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <button class="btn-modificar" type="button" onclick="window.location='<?php echo e(route('finalesSec')); ?>'">
            <i class="ri-arrow-left-line"></i>Volver
        </button>
        <br>

        <!-- HEADER -->
        <div class="top-bar">
            <h1>Agregar Final</h1>
        </div>

        <!-- FILTROS — solo cliente, sin form GET -->
        <div class="card-container">
            
            <div class="form-grid agregarFinal-grid">
                <label>Carrera</label>
                <select id="filtro-carreras">
                    <option value="-" selected disabled>Seleccionar</option>
                    <option value="A">Carrera A</option>
                    <option value="B">Carrera B</option>
                </select>

                <label>Año</label>
                <select id="filtro-anio">
                    <option value="-" selected disabled>Seleccionar</option>
                    <option value="A">1°</option>
                    <option value="B">2°</option>
                    <option value="B">3°</option>
                </select>

                <label>Aula</label>
                <div class="input-group">
                    <div class="fecha-hora-row">
                        <input
                            type="text"
                            name="aula"
                            id="aula"
                            placeholder="Número de aula"
                        >
                    </div>
                    <small class="error-message" id="error-numero"></small>
                </div>

                <label>Primer Fecha</label>
                <div class="input-group">
                    <div class="fecha-hora-row">
                        <input
                            type="date"
                            name="fecha_final_1"
                            id="fecha_final_1"
                        >
                        <input
                            type="time"
                            name="hora_final_1"
                            id="hora_final_1"
                        >
                    </div>
                    <small class="error-message" id="error-fecha_final_1"></small>
                </div>

                <label>Segunda Fecha</label>
                <div class="input-group">
                    <div class="fecha-hora-row">
                        <input
                            type="date"
                            name="fecha_final_2"
                            id="fecha_final_2"
                        >
                        <input
                            type="time"
                            name="hora_final_2"
                            id="hora_final_2"
                        >
                    </div>
                    <small class="error-message" id="error-fecha_final_2"></small>
                </div>
            </div>
        </div>

        <div class="table-container">

            <div class="top-bar">
                <h1>Docentes Asignados</h1>
            </div>

            
            <div class="dropdown" id="docente-dropdown">
                <input
                    type="text"
                    id="buscar-docente"
                    class="input-buscar-docente"
                    placeholder="Buscar docente"
                    autocomplete="off"
                >
                <div class="dropdown-menu" id="docente-dropdown-menu"></div>
            </div>

            <table class="cursada-table" id="tabla-docentes-asignados">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre y Apellido</th>
                        <th>DNI</th>
                        <th style="width:160px;">Tipo</th>
                        <th style="width:60px;"></th>
                    </tr>
                </thead>

                <tbody id="tabla-docentes-body">
                    <!-- Las filas se agregan acá por JS al elegir un docente del buscador -->
                </tbody>
            </table>

        </div>

        <div class="form-actions">
            <button type="button" class="btn-primary" id="btn-guardar">
                <i class="ri-save-line"></i> Guardar
            </button>
        </div>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="<?php echo e(asset('js/Secretaria/agregarFinal.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/finalesAgregarFecha.blade.php ENDPATH**/ ?>