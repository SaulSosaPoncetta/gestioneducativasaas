<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cargar notas final</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/cargarNota.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>

<body>
<button class="mobile-menu-btn" id="menu-btn">
    <i class="ri-menu-line"></i>
</button>
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <h1>Cargar notas final</h1>
        <br>
        <p class="help" style="margin-bottom:24px; font-size:18px;">
            <?php echo e($mesa->fecha); ?> <?php echo e($mesa->hora); ?> - <?php echo e($mesa->materia); ?> - <?php echo e($mesa->anio); ?>

        </p>

        <div id="alert-ajax" class="alert" style="display:none;"></div>

        <form id="form-notas-final" data-url="/cargarNotaFinal/<?php echo e($mesa->id_mesa); ?>">
            <?php echo csrf_field(); ?>

            <div class="table-container">
                <table class="cursada-table" id="tablaNotasFinal">
                    <thead>
                        <tr>
                            <th>Alumno</th>
                            <th style="width:140px;">Nota</th>
                            <th style="width:100px;">Intentos</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $alumnosFinal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($alumno->nombre); ?></td>
                            <td class="nota-cell">
                                <input
                                    type="text"
                                    inputmode="decimal"
                                    class="nota-input"
                                    name="nota_<?php echo e($alumno->id_usuario); ?>"
                                    id="nota_<?php echo e($alumno->id_usuario); ?>"
                                    placeholder="Nota"
                                >
                                <small class="error-message" id="error-nota_<?php echo e($alumno->id_usuario); ?>"></small>
                            </td>
                            <td><?php echo e($alumno->cant); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <div style="display:flex; justify-content:flex-start; gap:10px; margin-top:12px;">
                <button type="button" class="btn-primary" id="btn-guardar">
                    <i class="ri-save-line"></i> Guardar
                </button>
                <button type="button" class="btn-secondary" onclick="window.location.href='<?php echo e(route('finalPerfil', $mesa->id_mesa)); ?>'">
                    Volver
                </button>
            </div>

        </form>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="<?php echo e(asset('js/Secretaria/cargarNota.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/cargarNotasFinal.blade.php ENDPATH**/ ?>