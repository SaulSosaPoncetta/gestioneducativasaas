<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Plan de estudio - espacios</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/planEstudio.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/print.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/Filtro.js']); ?>
</head>

<body>
    <button class="mobile-menu-btn no-print" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    

    <div class="main">

        <?php
            $rol = auth()->user()->id_rol;
        ?>

        <div class="no-print">
            <?php if($rol == 1): ?>
                <button class="btn-modificar" type="button" onclick="window.location='<?php echo e(route('planEstudio.index')); ?>'">
                    <i class="ri-arrow-left-line"></i> Volver
                </button>
            <?php elseif($rol == 3): ?>
                <?php if($planResolucion): ?>
                    <button class="btn-modificar" type="button" onclick="window.location.href='<?php echo e(route('planEstudio.show', $planResolucion->id)); ?>'">
                        <i class="ri-arrow-left-line"></i> Volver
                    </button>
                <?php else: ?>
                    <button class="btn-modificar" type="button" onclick="window.history.back()">
                        <i class="ri-arrow-left-line"></i> Volver
                    </button>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        
        <div class="printable-area">

            <h1 class="page-title">Plan de estudios - Espacios curriculares — <?php echo e($carrera->nombre); ?></h1>

            <!-- FILTROS — solo cliente, sin form GET -->
            <div class="card-container no-print">
                <div class="form-grid">
                    <input
                        type="text"
                        id="filtro-nombre"
                        placeholder="Buscar materia"
                    >
                </div>
            </div>

            <div class="table-container">
                <table id="tablaEspacios" class="cursada-table">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Año</th>
                            <th>Nombre</th>
                            <th>Correlativas</th>
                            <th>Acreditación</th>
                            <th class="no-print">Perfil</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-id-materia="<?php echo e($materia->id_materia); ?>">
                                <td><?php echo e($materia->codigo); ?></td>
                                <td><?php echo e($materia->anio); ?>°</td>
                                <td class="celda-titulo"><?php echo e($materia->nombre); ?></td>
                                <td><?php echo e($materia->correlativas_texto ?: '—'); ?></td>
                                <td><?php echo e($materia->acreditacion); ?></td>
                                <td class="no-print">
                                    <?php if($rol == 1): ?>
                                        <button class="btn-primary" onclick="window.location.href='<?php echo e(route('materias.show', $materia->id_materia)); ?>'">Ver</button>
                                    <?php elseif($rol == 3): ?>
                                        <button class="btn-primary" onclick="window.location.href='<?php echo e(route('materias.show.estudiante', $materia->id_materia)); ?>'">Ver</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
        

        <button class="btn-primary no-print" type="button" onclick="window.print()">
            <i class="ri-printer-fill"></i> Imprimir
        </button>
    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Secretaria/planEspacios.blade.php ENDPATH**/ ?>