<footer>
    <pre>@2027 - SGI</pre>
</footer><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/partials/footer.blade.php ENDPATH**/ ?>