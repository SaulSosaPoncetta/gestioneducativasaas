<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Carrera</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Estudiante/carreraEst.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>

<body>
<button class="mobile-menu-btn" id="menu-btn">
    <i class="ri-menu-line"></i>
</button>
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php

    $alumno = (object)[
        'codigo' => '82422',
        'apellido' => 'Requena',
        'nombre' => 'Lucio',
    ];

    $carreras = [
        (object)[
            'id_carrera' => 1,
            'nombre' => 'Analista De sistema',
            'plan_estudio_id' => 1,
            'plan_estudio_nombre' => 'Analista De Sistemas Res. 6790/19',
            'cohorte' => '2024',
            'ultima_matriculacion' => '11/03/2025',
            'anio' => '2°',
            'se_recibio' => false,
            'promedio' => '8,00',
        ],
        (object)[
            'id_carrera' => 2,
            'nombre' => 'Tecnicatura en Programación',
            'plan_estudio_id' => 2,
            'plan_estudio_nombre' => 'Tecnicatura en Programación Res. 4410/21',
            'cohorte' => '2022',
            'ultima_matriculacion' => '05/03/2023',
            'anio' => '3°',
            'se_recibio' => true,
            'promedio' => '7,40',
        ],
    ];

    ?>

    <div class="main">
        <div class="perfil-header">
        <h1><?php echo e($alumno->codigo); ?>-<?php echo e($alumno->apellido); ?>, <?php echo e($alumno->nombre); ?></h1>
        </div>
        <div class="form-grid" style="max-width:600px; margin-top:24px;">

            <label for="filtro-carrera">Carrera</label>
            <div class="input-group">
                <select id="filtro-carrera">
                    <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($carrera->id_carrera); ?>"><?php echo e($carrera->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

        </div>
        <br>
        <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-grid datos-carrera" data-carrera="<?php echo e($carrera->id_carrera); ?>" style="max-width:600px; <?php echo e(!$loop->first ? 'display:none;' : ''); ?>">

            <label>Plan de estudio</label>
            <a href="<?php echo e(route('planEstudio.show', $carrera->plan_estudio_id)); ?>" style="color:#2563eb; font-weight:600;">
                <?php echo e($carrera->plan_estudio_nombre); ?>

            </a>
            <label>cohorte</label>
            <span><?php echo e($carrera->cohorte); ?></span>

            <label>Ultiima matriculacion</label>
            <span><?php echo e($carrera->ultima_matriculacion); ?></span>

            <label>Año</label>
            <span><?php echo e($carrera->anio); ?></span>

            <label>Se recibió</label>

            <?php if($carrera->se_recibio): ?>
                <span class="estado-ok">
                    <i class="ri-checkbox-circle-fill"></i> Sí
                </span>
            <?php else: ?>
                <span class="estado-no">
                    <i class="ri-close-circle-line"></i> No
                </span>
            <?php endif; ?>

            <label>Promedio</label>
            <span><?php echo e($carrera->promedio); ?></span>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
    document.addEventListener('DOMContentLoaded', function () {

        const filtroCarrera = document.getElementById('filtro-carrera');
        const bloques = document.querySelectorAll('.datos-carrera');

        filtroCarrera.addEventListener('change', function () {
            const seleccionada = filtroCarrera.value;

            bloques.forEach(function (bloque) {
                bloque.style.display = bloque.dataset.carrera === seleccionada ? '' : 'none';
            });
        });

    });
    </script>

</body>
</html>
<?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/Estudiante/carreraEst.blade.php ENDPATH**/ ?>