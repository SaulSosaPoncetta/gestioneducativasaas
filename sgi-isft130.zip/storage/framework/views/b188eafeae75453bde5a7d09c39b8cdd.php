<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Comprobante</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/materiaPerfil.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/comprobante.css')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body>
    <button class="mobile-menu-btn" id="menu-btn">
        <i class="ri-menu-line"></i>
    </button>

    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <button class="btn-modificar" type="button" onclick="window.history.back()">
            <i class="ri-arrow-left-line"></i>Volver
        </button>

        

        <div class="comprobante-wrapper">

            <div class="comprobante-box" id="comprobante-imprimible">

                <p class="comprobante-titulo">
                    Comprobante N° <span class="comprobante-numero">63888297573</span>
                </p>

                <div class="comprobante-datos">
                    <p><strong>Usuario</strong>: lucio.requena</p>
                    <p><strong>Fecha</strong>: 16/7/2025</p>
                    <p><strong>Hora</strong>: 21:19</p>
                    <p><strong>Operación</strong>: Inscripción a fecha de final Sistemas y Organizaciones (06/08/2025 18:10 hs)</p>
                </div>

                <div class="comprobante-verificacion">
                    Código de verificación: <span>63888297573</span>
                </div>

            </div>
            
            <button class="btn-primary" type="button" id="btn-imprimir" title="Imprimir comprobante" onclick="window.print()">
            <i class="ri-printer-fill"></i> Imprimir
            </button>

        </div>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="<?php echo e(asset('js/Secretaria/comprobante.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\Usuario\Documents\GitHub\sgi-isft130\laravel\resources\views/comprobante.blade.php ENDPATH**/ ?>