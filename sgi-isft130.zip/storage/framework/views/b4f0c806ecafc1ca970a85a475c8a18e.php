<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscar profesor</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/remixicon/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/sideBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/filtro.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tablas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/profesoresSec.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Secretaria/alumnosSec.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/Filtro.js']); ?>
</head>

<body>
<button class="mobile-menu-btn" id="menu-btn">
    <i class="ri-menu-line"></i>
</button>
<?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="main">

    <!-- HEADER -->
    <div class="top-bar">
        <h1>Ciclo Lectivo</h1>
        <button class="btn-primary" onclick="window.location.href='<?php echo e(route('cicloLectivoAgregar')); ?>'">Agregar Ciclo Lectivo</button>
    </div>

    <!-- FILTROS -->
    <form >
        <div class="card-container">
            <div class="form-grid">
                <input type="text" id="buscador-ciclo" placeholder="Buscar por año" name="buscar_año">
            </div>
        </div>
    </form>

    <div class="table-container">

        <table id="tablaCiclos" class="cursada-table">
            <thead>
                <tr>
                    <th>Año</th>
                    <th>Periodo</th>
                    <th>Ver</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ciclos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciclo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($ciclo->anio); ?>

                        </td>

                        <td>
                            <?php echo e($ciclo->fecha_inicio->format('d/m/Y')); ?>

                            -
                            <?php echo e($ciclo->fecha_fin->format('d/m/Y')); ?>

                        </td>

                        <td>
                            <a href="<?php echo e(route('cicloLectivoPerfil', $ciclo->id_ciclo)); ?>">
                                <button class="btn-primary" type="button">
                                    Ver
                                </button>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>      
        </table>

    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- recargar la pagina al volver para atras si estás en el perfil, por si hay modificaciones -->
    

</body>
</html>
<?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\sgi-isft130\resources\views/Secretaria/cicloLectivoSec.blade.php ENDPATH**/ ?>