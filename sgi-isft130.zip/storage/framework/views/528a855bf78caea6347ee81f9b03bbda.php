<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/log.css')); ?>">
</head>
<body>

    <div class="top">
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo">
    </div>

    <main>
        <div class="container">

            
            <?php if($errors->any()): ?>
                <div class="error-msg">
                    <?php echo e($errors->first('login')); ?>

                </div>
            <?php endif; ?>

            
            <form method="POST" action="<?php echo e(route('login.post')); ?>">
                <?php echo csrf_field(); ?>

                <input
                    type="text"
                    name="login"
                    placeholder="Usuario, DNI o mail"
                    value="<?php echo e(old('login')); ?>"
                >

                <input type="password" name="password" placeholder="Contraseña">

                <a href="<?php echo e(route('password.request')); ?>">Olvidé mi contraseña</a>

                <div class="captcha">
                    <div class="g-recaptcha" data-sitekey="6LdpLJwsAAAAABCGmdWy4K6OVEmcQPHo8IpSPypS"></div>
                </div>

                <button type="submit">Ingresar</button>
            </form>
        </div>
    </main>

    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    <footer>
        <p>@2027 - SGI</p>
    </footer>

</body>
</html><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\sgi-isft130\resources\views/auth/login.blade.php ENDPATH**/ ?>